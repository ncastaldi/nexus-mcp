"""Shard registration helpers."""
